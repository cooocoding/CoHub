<template>
	<view>
	    <view class="archived">
			
	      
	      
	    </view>
	    <!-- 页面内容 -->
	  </view>
</template>

<script>
	export default {
	  methods: {
	    //goBack() {
	    //  uni.navigateTo({
	    //      url: 'pages/list/list'
	    //  })
	    //}
	  }
	}
</script>

<style>
	
	
</style>